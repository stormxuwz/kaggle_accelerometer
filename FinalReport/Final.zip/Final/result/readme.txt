There are 5 folders, each represents a case. For the settings of each case, please see the report.

answer-knn1, answer-knn2: Multi-label classification with k=1 and 5
knn: 0-1 classification with k=5
lasso: lasso method
lda: linear discrimination analysis
rf: random forest
svm: svm with gaussian kernel
svm2: svm with linear kernel